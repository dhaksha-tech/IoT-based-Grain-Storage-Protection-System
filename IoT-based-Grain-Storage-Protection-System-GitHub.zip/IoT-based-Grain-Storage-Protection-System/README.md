# IoT-Based Grain Storage Protection System

> ESP32 + DHT22 + Blynk IoT system for monitoring grain-storage conditions and automatically controlling ventilation.

## Overview

The **IoT-Based Grain Storage Protection System** continuously monitors temperature and humidity using a DHT22 sensor connected to an ESP32.

The ESP32 sends sensor values through Wi-Fi to a Blynk dashboard. When the storage environment reaches an abnormal condition, the system activates a relay-controlled ventilation fan, changes the LED indication, and records a Blynk alert.

## Key Features

- Real-time temperature monitoring
- Real-time humidity monitoring
- ESP32-based processing
- Wi-Fi connectivity
- Blynk IoT dashboard
- Automatic abnormal-condition alert
- Automatic ventilation/fan control through relay
- Red/green LED status indication
- Serial Monitor output for debugging

## System Flow

```text
DHT22 Sensor
     │
     ▼
   ESP32
     │
     ├────────── Wi-Fi ──────────► Blynk Dashboard
     │
     ▼
 Condition Check
     │
     ├── Normal ─────► Green LED + Fan OFF
     │
     └── Abnormal ──► Red LED + Relay/Fan ON
                         │
                         ▼
                    Blynk Alert
```

## Hardware

| Component | Purpose |
|---|---|
| ESP32 | Main controller and Wi-Fi communication |
| DHT22 | Temperature and humidity sensing |
| Relay module | Controls ventilation fan |
| Ventilation fan | Reduces abnormal storage conditions |
| Red LED | Abnormal-condition indication |
| Green LED | Normal-condition indication |
| Resistors | LED current limiting |

## Pin Configuration

| Component | ESP32 GPIO |
|---|---:|
| DHT22 data | GPIO 4 |
| Relay | GPIO 26 |
| Green LED | GPIO 25 |
| Red LED | GPIO 27 |

## Blynk Virtual Pins

| Data | Virtual Pin |
|---|---|
| Temperature | V0 |
| Humidity | V1 |
| Fan Status | V2 |

Blynk event used by the sketch:

```text
storage_alert
```

## Threshold Logic

The supplied project code uses these values:

| Parameter | Threshold |
|---|---:|
| Temperature limit | 35 °C |
| Humidity limit | 70 % |
| Temperature reset | 33 °C |
| Humidity reset | 65 % |

### Abnormal condition

```text
Temperature >= 35 °C
OR
Humidity >= 70 %
```

Result:

```text
Fan = ON
Red LED = ON
Green LED = OFF
Blynk alert = logged
```

### Reset condition

```text
Temperature < 33 °C
AND
Humidity < 65 %
```

Result:

```text
Fan = OFF
Red LED = OFF
Green LED = ON
```

## Project Screenshots

### Circuit / Simulation

![Circuit simulation](circuit/circuit_diagram.jpg)

![Circuit simulation](images/circuit_simulation.jpg)

### Blynk Dashboard

![Blynk dashboard](images/blynk_dashboard.jpg)

### Simulation Output

![Simulation output](images/simulation_output.jpg)

The demonstration screenshot shows temperature and humidity readings with an abnormal-condition message and fan status.

## Code Screenshots

The original project code was supplied as screenshots and is preserved here for reference.

![Code 1](images/code_01.jpg)

![Code 2](images/code_02.jpg)

![Code 3](images/code_03.jpg)

![Code 4](images/code_04.jpg)

## Source Code

The Arduino sketch is available at:

```text
src/grain_storage_protection.ino
```

The sketch uses:

- `WiFi.h`
- `BlynkSimpleEsp32.h`
- `DHT.h`

Sensor readings are taken every **2 seconds** using `BlynkTimer`.

## Setup

1. Install the ESP32 board support in your Arduino-compatible development environment.
2. Install the required Blynk and DHT libraries.
3. Open `src/grain_storage_protection.ino`.
4. Replace the placeholder Wi-Fi credentials.
5. Replace the placeholder Blynk authentication token.
6. Configure the Blynk dashboard with V0, V1 and V2.
7. Create the `storage_alert` event.
8. Select the correct ESP32 board and COM port.
9. Upload the sketch.
10. Open Serial Monitor at **115200 baud**.

## Security

**Do not publish real Wi-Fi passwords or Blynk authentication tokens on GitHub.**

The repository intentionally contains:

```cpp
#define BLYNK_AUTH_TOKEN "YOUR_BLYNK_AUTH_TOKEN"

char ssid[] = "YOUR_WIFI_SSID";
char pass[] = "YOUR_WIFI_PASSWORD";
```

If a real Blynk token has already been exposed publicly, regenerate/revoke it before publishing the repository.

## Documentation

The project review document is included here:

```text
docs/IT-final-review.pdf
```

## Authors

- Dhatchayeni M
- Jayasree S
- Lavanya M

## Repository Structure

```text
IoT-based-Grain-Storage-Protection-System/
│
├── README.md
├── LICENSE
├── .gitignore
│
├── src/
│   ├── grain_storage_protection.ino
│   └── SOURCE_NOTE.md
│
├── circuit/
│   └── circuit_diagram.jpg
│
├── images/
│   ├── blynk_dashboard.jpg
│   ├── circuit_simulation.jpg
│   ├── simulation_output.jpg
│   ├── code_01.jpg
│   ├── code_02.jpg
│   ├── code_03.jpg
│   └── code_04.jpg
│
└── docs/
    └── IT-final-review.pdf
```

## Note

The `.ino` source file in this repository was reconstructed from the code visible in the supplied screenshots. Compare it with the original Wokwi/Arduino sketch before hardware deployment if you have the original source available.
