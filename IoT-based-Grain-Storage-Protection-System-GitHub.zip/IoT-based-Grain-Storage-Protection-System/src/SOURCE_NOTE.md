This sketch was reconstructed from the code screenshots supplied for the project. Credentials were replaced with placeholders. Compare with the original Wokwi sketch before deployment.
