#define BLYNK_TEMPLATE_ID "TMPL2Fb0G3Loi"
#define BLYNK_TEMPLATE_NAME "Grain Storage Protection"
#define BLYNK_AUTH_TOKEN "YOUR_BLYNK_AUTH_TOKEN"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <DHT.h>

#define DHTPIN 4
#define DHTTYPE DHT22

#define RELAY_PIN 26
#define GREEN_LED 25
#define RED_LED 27

char ssid[] = "YOUR_WIFI_SSID";
char pass[] = "YOUR_WIFI_PASSWORD";

DHT dht(DHTPIN, DHTTYPE);

const float TEMP_LIMIT = 35.0;
const float HUM_LIMIT = 70.0;

const float TEMP_RESET = 33.0;
const float HUM_RESET = 65.0;

bool fanState = false;
bool alertSent = false;

BlynkTimer timer;

void readSensors()
{
    float temperature = dht.readTemperature();
    float humidity = dht.readHumidity();

    if (isnan(temperature) || isnan(humidity))
    {
        Serial.println("DHT22 reading failed!");
        return;
    }

    Serial.print("Temperature: ");
    Serial.print(temperature);
    Serial.println(" °C");

    Serial.print("Humidity: ");
    Serial.print(humidity);
    Serial.println(" %");

    Blynk.virtualWrite(V0, temperature);
    Blynk.virtualWrite(V1, humidity);

    if (temperature >= TEMP_LIMIT || humidity >= HUM_LIMIT)
    {
        fanState = true;

        digitalWrite(RED_LED, HIGH);
        digitalWrite(GREEN_LED, LOW);

        Serial.println("WARNING: ABNORMAL CONDITION");
        Serial.println("FAN: ON");

        if (!alertSent)
        {
            Blynk.logEvent(
                "storage_alert",
                "High temperature or humidity detected!"
            );

            alertSent = true;
        }
    }
    else if (temperature < TEMP_RESET && humidity < HUM_RESET)
    {
        fanState = false;
        alertSent = false;

        digitalWrite(GREEN_LED, HIGH);
        digitalWrite(RED_LED, LOW);

        Serial.println("Storage readings within reset limits");
        Serial.println("FAN: OFF");
    }

    digitalWrite(RELAY_PIN, fanState ? HIGH : LOW);
    Blynk.virtualWrite(V2, fanState ? "ON" : "OFF");

    Serial.print("Fan Status: ");
    Serial.println(fanState ? "ON" : "OFF");
    Serial.println("------------------------------");
}

void setup()
{
    Serial.begin(115200);

    pinMode(RELAY_PIN, OUTPUT);
    pinMode(GREEN_LED, OUTPUT);
    pinMode(RED_LED, OUTPUT);

    digitalWrite(RELAY_PIN, LOW);
    digitalWrite(GREEN_LED, HIGH);
    digitalWrite(RED_LED, LOW);

    dht.begin();

    Serial.println("Grain Storage Protection System Started");

    WiFi.begin(ssid, pass);

    Serial.print("Connecting to WiFi");

    while (WiFi.status() != WL_CONNECTED)
    {
        delay(500);
        Serial.print(".");
    }

    Serial.println();
    Serial.println("WiFi Connected!");

    Blynk.config(BLYNK_AUTH_TOKEN);

    if (Blynk.connect(5000))
    {
        Serial.println("Blynk Connected!");
    }
    else
    {
        Serial.println("Blynk connection failed!");
    }

    timer.setInterval(2000L, readSensors);
}

void loop()
{
    Blynk.run();
    timer.run();
}
